__author__ = "Inada Naoki <songofacandy@gmail.com>"
__version__ = "2.2.4"
version_info = (2, 2, 4, "final", 0)
